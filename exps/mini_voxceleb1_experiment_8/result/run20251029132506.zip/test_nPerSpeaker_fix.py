#!/usr/bin/env python3
"""
Test script to verify nPerSpeaker label adjustment fix
"""
import torch

def test_label_adjustment():
    """Test that label adjustment works correctly for nPerSpeaker > 1"""
    
    print("=" * 80)
    print("Testing nPerSpeaker Label Adjustment Fix")
    print("=" * 80)
    
    # Simulate batch_size=4, nPerSpeaker=2
    batch_size = 4
    nPerSpeaker = 2
    embedding_dim = 256
    
    # Simulate labels as they come from DataLoader
    # Each speaker appears nPerSpeaker times consecutively
    # [speaker0, speaker0, speaker1, speaker1, speaker2, speaker2, speaker3, speaker3]
    original_labels = torch.tensor([0, 0, 1, 1, 2, 2, 3, 3])
    
    print(f"\n1. Original Setup:")
    print(f"   batch_size: {batch_size}")
    print(f"   nPerSpeaker: {nPerSpeaker}")
    print(f"   Total samples: {batch_size * nPerSpeaker}")
    print(f"   Original labels: {original_labels.tolist()}")
    print(f"   Original label shape: {original_labels.shape}")
    
    # Simulate embeddings (random)
    embeddings = torch.randn(batch_size * nPerSpeaker, embedding_dim)
    print(f"\n2. Embeddings shape before averaging: {embeddings.shape}")
    
    # Reshape and average (as in the model)
    embeddings_reshaped = embeddings.reshape(-1, nPerSpeaker, embedding_dim)
    embeddings_averaged = embeddings_reshaped.mean(dim=1)
    print(f"   Embeddings shape after averaging: {embeddings_averaged.shape}")
    
    # Apply label adjustment (the fix)
    adjusted_labels = original_labels[::nPerSpeaker]
    print(f"\n3. After Label Adjustment:")
    print(f"   Adjusted labels: {adjusted_labels.tolist()}")
    print(f"   Adjusted label shape: {adjusted_labels.shape}")
    
    # Verify dimensions match
    print(f"\n4. Dimension Check:")
    print(f"   Embeddings: {embeddings_averaged.shape[0]}")
    print(f"   Labels: {adjusted_labels.shape[0]}")
    print(f"   Match: {embeddings_averaged.shape[0] == adjusted_labels.shape[0]}")
    
    # Verify label values are correct
    expected_labels = torch.tensor([0, 1, 2, 3])
    print(f"\n5. Label Values Check:")
    print(f"   Expected: {expected_labels.tolist()}")
    print(f"   Got: {adjusted_labels.tolist()}")
    print(f"   Correct: {torch.equal(adjusted_labels, expected_labels)}")
    
    # Test with nPerSpeaker=1 (should not change)
    print(f"\n6. Test with nPerSpeaker=1:")
    nPerSpeaker_1 = 1
    labels_1 = torch.tensor([0, 1, 2, 3])
    adjusted_labels_1 = labels_1[::nPerSpeaker_1]
    print(f"   Original: {labels_1.tolist()}")
    print(f"   Adjusted: {adjusted_labels_1.tolist()}")
    print(f"   Unchanged: {torch.equal(labels_1, adjusted_labels_1)}")
    
    # Test with nPerSpeaker=3
    print(f"\n7. Test with nPerSpeaker=3:")
    nPerSpeaker_3 = 3
    labels_3 = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])
    adjusted_labels_3 = labels_3[::nPerSpeaker_3]
    expected_3 = torch.tensor([0, 1, 2])
    print(f"   Original: {labels_3.tolist()}")
    print(f"   Adjusted: {adjusted_labels_3.tolist()}")
    print(f"   Expected: {expected_3.tolist()}")
    print(f"   Correct: {torch.equal(adjusted_labels_3, expected_3)}")
    
    print("\n" + "=" * 80)
    print("✅ All tests passed! Label adjustment works correctly.")
    print("=" * 80)

if __name__ == '__main__':
    test_label_adjustment()
